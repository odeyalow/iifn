var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/send-phone/route.js")
R.c("server/chunks/node_modules_2060f09f._.js")
R.c("server/chunks/[root-of-the-server]__2da69c85._.js")
R.c("server/chunks/_next-internal_server_app_api_send-phone_route_actions_5b32719d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-phone/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/send-phone/route.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
