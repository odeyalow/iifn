module.exports = [
"[project]/.next-internal/server/app/[locale]/(pages)/conferences/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_%5Blocale%5D_%28pages%29_conferences_%5Bid%5D_page_actions_c1d705bf.js.map