module.exports = [
"[project]/public/locales/en/metadata.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_metadata_json_1fd85636._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/metadata.json (json)");
    });
});
}),
"[project]/public/locales/kz/metadata.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_metadata_json_a8ff1939._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/metadata.json (json)");
    });
});
}),
"[project]/public/locales/ru/metadata.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_metadata_json_ad2e291a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/metadata.json (json)");
    });
});
}),
"[project]/public/locales/en/home.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_home_json_29321b21._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/home.json (json)");
    });
});
}),
"[project]/public/locales/kz/home.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_home_json_0f93513a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/home.json (json)");
    });
});
}),
"[project]/public/locales/ru/home.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_home_json_82d3176b._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/home.json (json)");
    });
});
}),
"[project]/public/locales/en/headerFooter.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_headerFooter_json_8421459d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/headerFooter.json (json)");
    });
});
}),
"[project]/public/locales/kz/headerFooter.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_headerFooter_json_0badfd74._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/headerFooter.json (json)");
    });
});
}),
"[project]/public/locales/ru/headerFooter.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_headerFooter_json_843e317c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/headerFooter.json (json)");
    });
});
}),
"[project]/public/locales/en/aboutUs.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_aboutUs_json_29305c3e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/aboutUs.json (json)");
    });
});
}),
"[project]/public/locales/kz/aboutUs.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_aboutUs_json_42ea1e7e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/aboutUs.json (json)");
    });
});
}),
"[project]/public/locales/ru/aboutUs.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_aboutUs_json_a6b5eb78._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/aboutUs.json (json)");
    });
});
}),
"[project]/public/locales/en/conferences.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_conferences_json_f2e4976f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/conferences.json (json)");
    });
});
}),
"[project]/public/locales/kz/conferences.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_conferences_json_865e19dd._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/conferences.json (json)");
    });
});
}),
"[project]/public/locales/ru/conferences.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_conferences_json_eb4ed360._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/conferences.json (json)");
    });
});
}),
"[project]/public/locales/en/notFound.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_notFound_json_9752107d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/notFound.json (json)");
    });
});
}),
"[project]/public/locales/kz/notFound.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_notFound_json_4badd5eb._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/notFound.json (json)");
    });
});
}),
"[project]/public/locales/ru/notFound.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_notFound_json_5483c3af._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/notFound.json (json)");
    });
});
}),
"[project]/public/locales/en/news.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_en_news_json_35a333b6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/news.json (json)");
    });
});
}),
"[project]/public/locales/kz/news.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_kz_news_json_df33aa30._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/kz/news.json (json)");
    });
});
}),
"[project]/public/locales/ru/news.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/public_locales_ru_news_json_18bd9fee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/news.json (json)");
    });
});
}),
];