module.exports = [
"[project]/public/locales/en/headerFooter.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"logoText":"IFES","home":"Home","aboutUs":"About Us","conferences":"Conferences","journals":"Journals","contacts":"Contacts","seeAlso":"See Also","adress":"Almaty, Al-Farabi 71 bld. 2"});}),
];

//# sourceMappingURL=public_locales_en_headerFooter_json_8421459d._.js.map