module.exports = [
"[project]/public/locales/en/notFound.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"title":"Sorry, the page you are looking for was not found","underDevelopment":"Unfortunately, this page is still under development","goHome":"Go Back to Home"});}),
];

//# sourceMappingURL=public_locales_en_notFound_json_9752107d._.js.map