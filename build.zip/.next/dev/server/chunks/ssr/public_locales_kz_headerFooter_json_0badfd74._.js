module.exports = [
"[project]/public/locales/kz/headerFooter.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"logoText":"ИИФН","home":"Басты бет","aboutUs":"Біз туралы","conferences":"Конференциялар","journals":"Журналдар","contacts":"Байланыстар","seeAlso":"Сондай-ақ қараңыз","adress":"Алматы қ., Әл-Фараби 71 к2"});}),
];

//# sourceMappingURL=public_locales_kz_headerFooter_json_0badfd74._.js.map