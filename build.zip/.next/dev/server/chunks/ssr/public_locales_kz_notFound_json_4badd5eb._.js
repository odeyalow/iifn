module.exports = [
"[project]/public/locales/kz/notFound.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"title":"Өкінішке орай, іздеп отырған бетіңіз табылмады","underDevelopment":"Өкінішке орай, бұл бет әлі де құрастырылу үстінде.","goHome":"Басты бетке оралу"});}),
];

//# sourceMappingURL=public_locales_kz_notFound_json_4badd5eb._.js.map