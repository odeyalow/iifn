module.exports = [
"[project]/public/locales/ru/headerFooter.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"logoText":"ИИФН","home":"Главная","aboutUs":"О нас","conferences":"Конференции","journals":"Журналы","contacts":"Контакты","seeAlso":"Смотрите также","adress":"г. Алматы, Аль-фараби 71 к2"});}),
];

//# sourceMappingURL=public_locales_ru_headerFooter_json_843e317c._.js.map