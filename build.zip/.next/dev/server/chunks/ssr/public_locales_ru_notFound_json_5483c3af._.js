module.exports = [
"[project]/public/locales/ru/notFound.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v({"title":"К сожалению, страница которую вы ищете не найдена","underDevelopment":"К сожалению, эта страница еще в разработке","goHome":"Вернуться на главную"});}),
];

//# sourceMappingURL=public_locales_ru_notFound_json_5483c3af._.js.map