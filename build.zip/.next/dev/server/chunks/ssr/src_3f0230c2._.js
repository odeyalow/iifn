module.exports = [
"[project]/src/i18n/routing.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "routing",
    ()=>routing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$routing$2f$defineRouting$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__defineRouting$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/routing/defineRouting.js [app-rsc] (ecmascript) <export default as defineRouting>");
;
const routing = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$routing$2f$defineRouting$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__defineRouting$3e$__["defineRouting"])({
    locales: [
        'kz',
        'ru',
        'en'
    ],
    defaultLocale: 'kz'
});
}),
"[project]/src/i18n/request.js [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>getConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$routing$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/i18n/routing.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
;
;
const NAMESPACES = [
    'metadata',
    'home',
    'headerFooter',
    'aboutUs',
    'news',
    'conferences',
    'journals',
    'notFound'
];
// Кэш для сообщений
const messagesCache = {};
async function getConfig({ requestLocale }) {
    const locale = await requestLocale ?? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$routing$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["routing"].defaultLocale;
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$routing$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["routing"].locales.includes(locale)) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    // Проверим кэш
    if (messagesCache[locale]) {
        return {
            locale,
            messages: messagesCache[locale]
        };
    }
    const messages = {};
    await Promise.all(NAMESPACES.map(async (ns)=>{
        try {
            const mod = await __turbopack_context__.f({
                "../../public/locales/en/metadata.json": {
                    id: ()=>"[project]/public/locales/en/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/metadata.json (json, async loader)")
                },
                "../../public/locales/kz/metadata.json": {
                    id: ()=>"[project]/public/locales/kz/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/metadata.json (json, async loader)")
                },
                "../../public/locales/ru/metadata.json": {
                    id: ()=>"[project]/public/locales/ru/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/metadata.json (json, async loader)")
                },
                "../../public/locales/en/home.json": {
                    id: ()=>"[project]/public/locales/en/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/home.json (json, async loader)")
                },
                "../../public/locales/kz/home.json": {
                    id: ()=>"[project]/public/locales/kz/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/home.json (json, async loader)")
                },
                "../../public/locales/ru/home.json": {
                    id: ()=>"[project]/public/locales/ru/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/home.json (json, async loader)")
                },
                "../../public/locales/en/headerFooter.json": {
                    id: ()=>"[project]/public/locales/en/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/headerFooter.json (json, async loader)")
                },
                "../../public/locales/kz/headerFooter.json": {
                    id: ()=>"[project]/public/locales/kz/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/headerFooter.json (json, async loader)")
                },
                "../../public/locales/ru/headerFooter.json": {
                    id: ()=>"[project]/public/locales/ru/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/headerFooter.json (json, async loader)")
                },
                "../../public/locales/en/aboutUs.json": {
                    id: ()=>"[project]/public/locales/en/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/aboutUs.json (json, async loader)")
                },
                "../../public/locales/kz/aboutUs.json": {
                    id: ()=>"[project]/public/locales/kz/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/aboutUs.json (json, async loader)")
                },
                "../../public/locales/ru/aboutUs.json": {
                    id: ()=>"[project]/public/locales/ru/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/aboutUs.json (json, async loader)")
                },
                "../../public/locales/en/news.json": {
                    id: ()=>"[project]/public/locales/en/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/news.json (json, async loader)")
                },
                "../../public/locales/kz/news.json": {
                    id: ()=>"[project]/public/locales/kz/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/news.json (json, async loader)")
                },
                "../../public/locales/ru/news.json": {
                    id: ()=>"[project]/public/locales/ru/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/news.json (json, async loader)")
                },
                "../../public/locales/en/conferences.json": {
                    id: ()=>"[project]/public/locales/en/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/conferences.json (json, async loader)")
                },
                "../../public/locales/kz/conferences.json": {
                    id: ()=>"[project]/public/locales/kz/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/conferences.json (json, async loader)")
                },
                "../../public/locales/ru/conferences.json": {
                    id: ()=>"[project]/public/locales/ru/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/conferences.json (json, async loader)")
                },
                "../../public/locales/en/notFound.json": {
                    id: ()=>"[project]/public/locales/en/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/notFound.json (json, async loader)")
                },
                "../../public/locales/kz/notFound.json": {
                    id: ()=>"[project]/public/locales/kz/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/notFound.json (json, async loader)")
                },
                "../../public/locales/ru/notFound.json": {
                    id: ()=>"[project]/public/locales/ru/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/notFound.json (json, async loader)")
                },
                "../../public/locales//en/aboutUs.json": {
                    id: ()=>"[project]/public/locales/en/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/aboutUs.json (json, async loader)")
                },
                "../../public/locales//en/conferences.json": {
                    id: ()=>"[project]/public/locales/en/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/conferences.json (json, async loader)")
                },
                "../../public/locales//en/headerFooter.json": {
                    id: ()=>"[project]/public/locales/en/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/headerFooter.json (json, async loader)")
                },
                "../../public/locales//en/home.json": {
                    id: ()=>"[project]/public/locales/en/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/home.json (json, async loader)")
                },
                "../../public/locales//en/metadata.json": {
                    id: ()=>"[project]/public/locales/en/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/metadata.json (json, async loader)")
                },
                "../../public/locales//en/news.json": {
                    id: ()=>"[project]/public/locales/en/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/news.json (json, async loader)")
                },
                "../../public/locales//en/notFound.json": {
                    id: ()=>"[project]/public/locales/en/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/en/notFound.json (json, async loader)")
                },
                "../../public/locales//kz/aboutUs.json": {
                    id: ()=>"[project]/public/locales/kz/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/aboutUs.json (json, async loader)")
                },
                "../../public/locales//kz/conferences.json": {
                    id: ()=>"[project]/public/locales/kz/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/conferences.json (json, async loader)")
                },
                "../../public/locales//kz/headerFooter.json": {
                    id: ()=>"[project]/public/locales/kz/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/headerFooter.json (json, async loader)")
                },
                "../../public/locales//kz/home.json": {
                    id: ()=>"[project]/public/locales/kz/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/home.json (json, async loader)")
                },
                "../../public/locales//kz/metadata.json": {
                    id: ()=>"[project]/public/locales/kz/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/metadata.json (json, async loader)")
                },
                "../../public/locales//kz/news.json": {
                    id: ()=>"[project]/public/locales/kz/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/news.json (json, async loader)")
                },
                "../../public/locales//kz/notFound.json": {
                    id: ()=>"[project]/public/locales/kz/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/kz/notFound.json (json, async loader)")
                },
                "../../public/locales//ru/aboutUs.json": {
                    id: ()=>"[project]/public/locales/ru/aboutUs.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/aboutUs.json (json, async loader)")
                },
                "../../public/locales//ru/conferences.json": {
                    id: ()=>"[project]/public/locales/ru/conferences.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/conferences.json (json, async loader)")
                },
                "../../public/locales//ru/headerFooter.json": {
                    id: ()=>"[project]/public/locales/ru/headerFooter.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/headerFooter.json (json, async loader)")
                },
                "../../public/locales//ru/home.json": {
                    id: ()=>"[project]/public/locales/ru/home.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/home.json (json, async loader)")
                },
                "../../public/locales//ru/metadata.json": {
                    id: ()=>"[project]/public/locales/ru/metadata.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/metadata.json (json, async loader)")
                },
                "../../public/locales//ru/news.json": {
                    id: ()=>"[project]/public/locales/ru/news.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/news.json (json, async loader)")
                },
                "../../public/locales//ru/notFound.json": {
                    id: ()=>"[project]/public/locales/ru/notFound.json (json, async loader)",
                    module: ()=>__turbopack_context__.A("[project]/public/locales/ru/notFound.json (json, async loader)")
                }
            }).import(`../../public/locales/${locale}/${ns}.json`);
            messages[ns] = mod.default ?? {};
        } catch (e) {
            messages[ns] = {};
        }
    }));
    // Кэшируем результат
    messagesCache[locale] = messages;
    return {
        locale,
        messages
    };
}
}),
"[project]/src/components/layouts/header.jsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layouts/header.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layouts/header.jsx <module evaluation>", "default");
}),
"[project]/src/components/layouts/header.jsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layouts/header.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layouts/header.jsx", "default");
}),
"[project]/src/components/layouts/header.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$header$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/layouts/header.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$header$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/components/layouts/header.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$header$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/components/layouts/footer.jsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layouts/footer.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layouts/footer.jsx <module evaluation>", "default");
}),
"[project]/src/components/layouts/footer.jsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/layouts/footer.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/layouts/footer.jsx", "default");
}),
"[project]/src/components/layouts/footer.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$footer$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/layouts/footer.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$footer$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/components/layouts/footer.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$footer$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/components/layouts/mainLayout.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$header$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layouts/header.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$footer$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layouts/footer.jsx [app-rsc] (ecmascript)");
;
;
;
const MainLayout = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "relative w-full h-max bg-white pt-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$header$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/layouts/mainLayout.jsx",
                lineNumber: 7,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[1280px] mx-auto min-h-svh px-10 max-[1280px]:overflow-x-hidden",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/layouts/mainLayout.jsx",
                lineNumber: 8,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$footer$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/components/layouts/mainLayout.jsx",
                lineNumber: 11,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/layouts/mainLayout.jsx",
        lineNumber: 6,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = MainLayout;
}),
"[project]/src/app/[locale]/layout.jsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RootLayout,
    "dynamic",
    ()=>dynamic,
    "dynamicParams",
    ()=>dynamicParams,
    "generateStaticParams",
    ()=>generateStaticParams
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$server$2f$NextIntlClientProviderServer$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__NextIntlClientProvider$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-server/NextIntlClientProviderServer.js [app-rsc] (ecmascript) <export default as NextIntlClientProvider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$routing$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/i18n/routing.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$request$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/i18n/request.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$mainLayout$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/layouts/mainLayout.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
const dynamic = 'force-static';
const dynamicParams = false;
async function generateStaticParams() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$routing$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["routing"].locales.map((locale)=>({
            locale
        }));
}
async function RootLayout({ children, params }) {
    const { locale } = await params;
    const { messages } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$i18n$2f$request$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])({
        requestLocale: Promise.resolve(locale)
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: locale,
        suppressHydrationWarning: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$server$2f$NextIntlClientProviderServer$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$export__default__as__NextIntlClientProvider$3e$__["NextIntlClientProvider"], {
                locale: locale,
                messages: messages,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$layouts$2f$mainLayout$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                    children: children
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/layout.jsx",
                    lineNumber: 29,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/layout.jsx",
                lineNumber: 28,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/[locale]/layout.jsx",
            lineNumber: 27,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/[locale]/layout.jsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=src_3f0230c2._.js.map